class CancellationException(Exception):
    """Command was cancelled from the CloudShell"""
    pass
