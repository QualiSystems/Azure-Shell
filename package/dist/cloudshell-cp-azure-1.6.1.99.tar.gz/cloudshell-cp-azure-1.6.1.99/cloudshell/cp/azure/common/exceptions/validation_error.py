class ValidationError(Exception):
    pass
