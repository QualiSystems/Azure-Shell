class SSHKey(object):
    def __init__(self, private_key, public_key):
        self.private_key = private_key
        self.public_key = public_key
