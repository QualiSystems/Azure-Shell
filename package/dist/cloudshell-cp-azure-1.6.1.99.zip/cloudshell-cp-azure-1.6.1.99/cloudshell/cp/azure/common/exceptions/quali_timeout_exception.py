class QualiTimeoutException(Exception):
    pass


class QualiScriptExecutionTimeoutException(Exception):
    pass
