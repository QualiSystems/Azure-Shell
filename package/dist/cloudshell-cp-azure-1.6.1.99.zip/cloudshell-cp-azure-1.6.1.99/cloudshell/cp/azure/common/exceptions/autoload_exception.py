class AutoloadException(Exception):
    pass